self.__precacheManifest = [
  {
    "revision": "7c6a40befe9eaa10d454",
    "url": "/js/about.a08dc33c.js"
  },
  {
    "revision": "7df838bf4406e103e45b",
    "url": "/css/app.976f21ed.css"
  },
  {
    "revision": "7df838bf4406e103e45b",
    "url": "/js/app.2274198a.js"
  },
  {
    "revision": "9422cf0465c4fa1596f7",
    "url": "/css/chunk-vendors.c346ccd8.css"
  },
  {
    "revision": "9422cf0465c4fa1596f7",
    "url": "/js/chunk-vendors.600875a5.js"
  },
  {
    "revision": "c774cc6f2499d2b0d15a75179268eeb3",
    "url": "/fonts/materialdesignicons-webfont.c774cc6f.woff2"
  },
  {
    "revision": "848935b04b3f6512d1f47de14de9ba33",
    "url": "/fonts/materialdesignicons-webfont.848935b0.woff"
  },
  {
    "revision": "f6e666527036392fb3d0030d50118269",
    "url": "/fonts/materialdesignicons-webfont.f6e66652.ttf"
  },
  {
    "revision": "84cd5ee65fd195790df16e5d0075e99f",
    "url": "/fonts/materialdesignicons-webfont.84cd5ee6.eot"
  },
  {
    "revision": "5a5c9d622246f7ca2df22b71c162188c",
    "url": "/img/bafouille.5a5c9d62.svg"
  },
  {
    "revision": "041a257b7d4d98f06f19229aa0b9b872",
    "url": "/index.html"
  },
  {
    "revision": "49621dd41906dbfb01eaec71158565b0",
    "url": "/_headers"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
];